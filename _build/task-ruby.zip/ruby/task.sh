#!/usr/bin/env bash

ruby task.rb "$@"
