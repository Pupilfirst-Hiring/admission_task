#!/usr/bin/env bash

java Task "$@"
