#!/usr/bin/env bash

node task.js "$@"
